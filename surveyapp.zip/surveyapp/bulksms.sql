-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2020 at 12:52 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bulksms`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `email`) VALUES
(1, 'otingajackton', '0700309590', 'otingajackton@gmail.com'),
(2, 'mohanja', '0700309590', '17g01acs021@anu.ac.ke');

-- --------------------------------------------------------

--
-- Table structure for table `deliveryreport`
--

CREATE TABLE `deliveryreport` (
  `id` int(11) NOT NULL,
  `Time` datetime(6) NOT NULL,
  `to_number` varchar(255) NOT NULL,
  `network` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deliveryreport`
--

INSERT INTO `deliveryreport` (`id`, `Time`, `to_number`, `network`, `status`) VALUES
(9, '2020-04-27 21:21:17.843448', '+254700309590', '63902', 'Success'),
(10, '2020-04-27 21:23:38.929092', '+254700309590', '63902', 'Success'),
(11, '2027-04-20 21:39:06.000000', '+254700309590', '63902', 'Success'),
(12, '2020-04-27 21:43:01.000000', '+254700309590', '63902', 'Success'),
(13, '2020-04-27 21:51:07.000000', '+254700309590', '63902', 'Success'),
(14, '2020-04-28 00:05:37.000000', '+254700309590', '63902', 'Success'),
(15, '2020-04-28 00:07:47.000000', '+254700309590', '63902', 'Success'),
(16, '2020-04-28 03:39:28.000000', '+254700309590', '63902', 'Success'),
(17, '2020-04-28 03:46:09.000000', '+254700309590', '63902', 'Success'),
(18, '2020-04-28 05:11:15.000000', '+254700309590', '63902', 'Success'),
(19, '2020-04-28 06:04:12.000000', '+254700309590', '63902', 'Success'),
(20, '2020-04-28 06:04:29.000000', '+254700309590', '63902', 'Success'),
(21, '2020-04-28 06:12:34.000000', '+254746898835', '63902', 'Success'),
(22, '2020-04-28 06:13:07.000000', '+254700309590', '63902', 'Success'),
(23, '2020-04-28 06:24:16.000000', '+254722583919', '63902', 'Success'),
(24, '2020-04-28 06:24:17.000000', '+254722583919', '63902', 'Success'),
(25, '2020-04-28 06:24:23.000000', '+254722583919', '63902', 'Success'),
(26, '2020-04-28 06:24:27.000000', '+254722583919', '63902', 'Success'),
(27, '2020-04-28 06:24:30.000000', '+254722583919', '63902', 'Success'),
(28, '2020-04-28 06:24:30.000000', '+254722583919', '63902', 'Success'),
(29, '2020-04-28 06:24:41.000000', '+254722583919', '63902', 'Success');

-- --------------------------------------------------------

--
-- Table structure for table `phoneno`
--

CREATE TABLE `phoneno` (
  `id` int(11) NOT NULL,
  `phoneNo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phoneno`
--

INSERT INTO `phoneno` (`id`, `phoneNo`) VALUES
(1, '+254700309590'),
(2, '+254722583919'),
(3, '+254746898835');

-- --------------------------------------------------------

--
-- Table structure for table `sendingsms`
--

CREATE TABLE `sendingsms` (
  `id` int(10) NOT NULL,
  `Date` datetime(6) NOT NULL,
  `Text` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sendingsms`
--

INSERT INTO `sendingsms` (`id`, `Date`, `Text`, `Status`) VALUES
(19, '2020-04-27 17:45:30.000000', 'i love you', 'SEND'),
(20, '2020-04-27 18:05:35.000000', 'API KEY IS WORKING', 'SEND'),
(22, '2020-04-27 18:58:24.000000', 'i love you', 'SEND'),
(23, '2020-04-27 20:42:25.000000', 'mmmm', 'SEND'),
(24, '2020-04-27 20:55:42.000000', 'i love you', 'SEND'),
(25, '2020-04-27 21:01:05.000000', 'i love you', 'SEND'),
(26, '2020-04-27 21:03:45.000000', 'i love you', 'SEND'),
(27, '2020-04-27 21:21:10.000000', 'i love you', 'SEND'),
(28, '2020-04-27 21:23:32.000000', 'i love you', 'SEND'),
(29, '2020-04-27 21:37:56.000000', 'mmmm', 'SEND'),
(30, '2020-04-27 21:42:53.000000', 'i love you', 'SEND'),
(31, '2020-04-27 21:44:07.000000', 'i love you', 'SEND'),
(32, '2020-04-28 00:04:26.000000', 'i love you', 'SEND'),
(33, '2020-04-28 00:07:37.000000', 'i love you', 'SEND');

-- --------------------------------------------------------

--
-- Stand-in structure for view `smsview`
-- (See below for the actual view)
--
CREATE TABLE `smsview` (
`date` datetime(6)
,`text` varchar(255)
,`to_number` varchar(255)
,`status` varchar(255)
,`network` varchar(255)
);

-- --------------------------------------------------------

--
-- Structure for view `smsview`
--
DROP TABLE IF EXISTS `smsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `smsview`  AS  select `a`.`Date` AS `date`,`a`.`Text` AS `text`,`b`.`to_number` AS `to_number`,`b`.`status` AS `status`,`b`.`network` AS `network` from (`sendingsms` `a` join `deliveryreport` `b`) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliveryreport`
--
ALTER TABLE `deliveryreport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `phoneno`
--
ALTER TABLE `phoneno`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sendingsms`
--
ALTER TABLE `sendingsms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `deliveryreport`
--
ALTER TABLE `deliveryreport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `phoneno`
--
ALTER TABLE `phoneno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sendingsms`
--
ALTER TABLE `sendingsms`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
